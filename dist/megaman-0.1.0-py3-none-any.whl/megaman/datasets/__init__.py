from .datasets import (
    generate_megaman_data,
    generate_megaman_manifold,
    generate_noisefree_hourglass,
    generate_noisy_hourglass,
    get_megaman_image,
)
