"""megaman: Scalable Manifold Learning"""

# LICENSE: Simplified BSD https://github.com/mmp2/megaman/blob/master/LICENSE
