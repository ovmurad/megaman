# LICENSE: Simplified BSD https://github.com/mmp2/megaman/blob/master/LICENSE

from .plotter import (
    plot_embedding_with_matplotlib,
    plot_embedding_with_plotly,
    plot_with_matplotlib,
    plot_with_plotly,
)
